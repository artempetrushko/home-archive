#include <stdlib.h>
#include <stdio.h>

int main(void)
{
  printf("Hello world\n");
  return EXIT_SUCCESS;
}
